package com.example.a_zservices7.Prevalent;

import com.example.a_zservices7.Model.Users;

public class Prevalent {
    public static Users currentOnlineUser; // Assuming you have a User class

    // You can add other static variables or methods as needed
}
