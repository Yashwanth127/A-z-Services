package com.example.a_zservices7;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.FirebaseTooManyRequestsException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class RegisterActivity extends AppCompatActivity {

    private EditText Name, Password, Phone;
    private Button Register;
    private DatabaseReference mref;
    private FirebaseAuth mAuth;
    private ProgressDialog LoadingBar;
    private String VerificationId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Initialize Firebase references
        mref = FirebaseDatabase.getInstance().getReference();
        mAuth = FirebaseAuth.getInstance();

        // Set up views
        Name = findViewById(R.id.nameentry);
        Password = findViewById(R.id.passwordentry);
        Phone = findViewById(R.id.phoneentry);
        Register = findViewById(R.id.registerbutton);
        LoadingBar = new ProgressDialog(this);

        // Handle registration click event
        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Validate input fields
                if (TextUtils.isEmpty(Name.getText().toString())) {
                    Toast.makeText(RegisterActivity.this, "Please enter your name first.", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(Phone.getText().toString())) {
                    Toast.makeText(RegisterActivity.this, "Please enter your Phone Number.", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(Password.getText().toString())) {
                    Toast.makeText(RegisterActivity.this, "Please enter your password.", Toast.LENGTH_SHORT).show();
                } else {
                    // Check if the phone number already exists in the database
                    mref.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            if (!(dataSnapshot.child("Users").child(Phone.getText().toString()).exists())) {
                                // Phone number doesn't exist, proceed to send OTP
                                sendVerificationCode(Phone.getText().toString());
                            } else {
                                // Phone number already registered
                                Toast.makeText(RegisterActivity.this, "Account with this number already exists.", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                            // Handle error if database query is cancelled
                            Toast.makeText(RegisterActivity.this, "Error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });
    }

    private void sendVerificationCode(String phone) {
        LoadingBar.setTitle("Sending OTP");
        LoadingBar.setMessage("Please wait...");
        LoadingBar.show();

        PhoneAuthOptions options =
                PhoneAuthOptions.newBuilder(mAuth)
                        .setPhoneNumber("+91" + phone) // Correct usage of phone text input
                        .setTimeout(60L, TimeUnit.SECONDS) // Timeout
                        .setActivity(this) // Activity for callbacks
                        .setCallbacks(mCallbacks) // OnVerificationStateChangedCallbacks
                        .build();
        PhoneAuthProvider.verifyPhoneNumber(options);
    }

    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks =
            new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                @Override
                public void onCodeSent(@NonNull String verificationId, @NonNull PhoneAuthProvider.ForceResendingToken token) {
                    super.onCodeSent(verificationId, token);
                    VerificationId = verificationId; // Save the verification ID sent by Firebase
                    showOtpDialog();
                    LoadingBar.dismiss(); // Dismiss after OTP is sent
                }

                @Override
                public void onVerificationCompleted(@NonNull PhoneAuthCredential credential) {
                    // Automatically verify if the code is sent
                    signInWithCredential(credential);
                    LoadingBar.dismiss(); // Dismiss once verification is completed
                }

                @Override
                public void onVerificationFailed(@NonNull FirebaseException e) {
                    LoadingBar.dismiss(); // Dismiss in case of error
                    if (e instanceof FirebaseAuthInvalidCredentialsException) {
                        Toast.makeText(RegisterActivity.this, "Invalid phone number format.", Toast.LENGTH_SHORT).show();
                    } else if (e instanceof FirebaseTooManyRequestsException) {
                        Toast.makeText(RegisterActivity.this, "Quota exceeded. Try again later.", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(RegisterActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            };

    // OTP Dialog for user input
    private void showOtpDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Enter OTP");
        builder.setView(R.layout.otp_dialog); // Replace with your dialog layout

        builder.setPositiveButton("Verify", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                EditText otpInput = ((AlertDialog) dialog).findViewById(R.id.otpInput); // Find OTP input field
                if (otpInput != null) {
                    String otp = otpInput.getText().toString();
                    verifyCode(otp);
                } else {
                    Toast.makeText(RegisterActivity.this, "Error in retrieving OTP field", Toast.LENGTH_SHORT).show();
                }
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void verifyCode(String code) {
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(VerificationId, code);
        signInWithCredential(credential);
    }

    private void signInWithCredential(PhoneAuthCredential credential) {
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // User authenticated successfully, create account
                            createAccount(Phone.getText().toString(), Name.getText().toString(), Password.getText().toString());
                        } else {
                            // Authentication failed
                            Toast.makeText(RegisterActivity.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void createAccount(String phone, String name, String password) {
        Map<String, Object> details = new HashMap<>();
        details.put("Phone", phone);
        details.put("Name", name);
        details.put("Password", password);
        details.put("Address", ""); // Empty address for now

        // Save user details in Firebase Database
        mref.child("Users").child(phone).setValue(details)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            // Redirect to LoginActivity after successful registration
                            Intent i = new Intent(RegisterActivity.this, LoginActivity.class);
                            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(i);
                            finish(); // Optional: finish the RegisterActivity
                        } else {
                            Toast.makeText(RegisterActivity.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
}
