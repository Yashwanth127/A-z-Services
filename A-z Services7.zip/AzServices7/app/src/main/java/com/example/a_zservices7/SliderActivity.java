package com.example.a_zservices7;

import android.content.Intent;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class SliderActivity extends AppCompatActivity implements View.OnClickListener {

    private ViewPager mPager;
    private int[] layouts = {
            R.layout.first_slide,
            R.layout.second_slide,
            R.layout.third_slide,
            R.layout.fourth_slide
    };
    private MPagerAdapter mPagerAdapter;
    private LinearLayout Dots_Layout;
    private ImageView[] dots;
    private Button BnNext, BnSkip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slider);

        if (new PreferenceManager(this).checkPreference()) {
            loadHome();
        }

        BnNext = findViewById(R.id.bnNext);
        BnSkip = findViewById(R.id.bnSkip);
        BnSkip.setOnClickListener(this);
        BnNext.setOnClickListener(this);

        mPager = findViewById(R.id.viewPager);
        mPagerAdapter = new MPagerAdapter(layouts, this);
        mPager.setAdapter(mPagerAdapter);

        Dots_Layout = findViewById(R.id.dotslayout);
        createDots(0);

        mPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {}

            @Override
            public void onPageSelected(int i) {
                createDots(i);
                if (i == layouts.length - 1) {
                    BnNext.setText("Start");
                    BnSkip.setVisibility(View.INVISIBLE);
                } else {
                    BnNext.setText("Next");
                    BnSkip.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onPageScrollStateChanged(int i) {}
        });
    }

    private void createDots(int current_position) {
        if (Dots_Layout != null) {
            Dots_Layout.removeAllViews();
        }

        dots = new ImageView[layouts.length];
        for (int i = 0; i < layouts.length; i++) {
            dots[i] = new ImageView(this);
            if (i == current_position) {
                dots[i].setImageDrawable(ContextCompat.getDrawable(this, R.drawable.active_dots));
            } else {
                dots[i].setImageDrawable(ContextCompat.getDrawable(this, R.drawable.default_dots));
            }
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
            params.setMargins(4, 0, 4, 0);
            Dots_Layout.addView(dots[i], params);
        }
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.bnNext) {
            loadNextSlide();
        } else if (v.getId() == R.id.bnSkip) {
            loadHome();
            new PreferenceManager(this).writePreference();
        }
    }

    private void loadHome() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }

    private void loadNextSlide() {
        int next_slide = mPager.getCurrentItem() + 1;

        if (next_slide < layouts.length) {
            mPager.setCurrentItem(next_slide);
        } else {
            loadHome();
            new PreferenceManager(this).writePreference();
        }
    }
}
