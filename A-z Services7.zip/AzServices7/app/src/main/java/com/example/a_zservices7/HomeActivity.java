package com.example.a_zservices7;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.a_zservices.Prevalent.Prevalent;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;


public class HomeActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private Button[] serviceButtons;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        setupToolbar();
        setupFloatingActionButton();
        setupDrawer();
        setupServiceButtons();
        displayCurrentUser();
    }

    private void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Home");
        setSupportActionBar(toolbar);
    }

    private void setupFloatingActionButton() {
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(view -> {
            if (Prevalent.currentOnlineUser.getPhone().equals("+911111111111")) {
                Toast.makeText(HomeActivity.this, "Login First to Send Email..", Toast.LENGTH_LONG).show();
                startActivity(new Intent(HomeActivity.this, LoginActivity.class));
            } else {
                startActivity(new Intent(HomeActivity.this, EmailActivity.class));
            }
        });
    }

    private void setupDrawer() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    private void displayCurrentUser() {
        View headerView = ((NavigationView) findViewById(R.id.nav_view)).getHeaderView(0);
        TextView currentUser = headerView.findViewById(R.id.currentuser);
        currentUser.setText(Prevalent.currentOnlineUser.getName());
    }

    private void setupServiceButtons() {
        String[] serviceNames = {"Electrician", "Plumber", "Driver", "Carpenter", "BabySitter",
                "Painter", "Tutor", "Guard", "AcElectrician",
                "ComputerOperator", "Dumper", "InteriorDesigner", "Mason",
                "SoftwareInstaller"};

        serviceButtons = new Button[serviceNames.length];

        for (int i = 0; i < serviceNames.length; i++) {
            int resId = getResources().getIdentifier("btn" + serviceNames[i].toLowerCase(), "id", getPackageName());
            serviceButtons[i] = findViewById(resId);
            int finalI = i;
            serviceButtons[i].setOnClickListener(v -> {
                Intent intent = new Intent(HomeActivity.this, MessageActivity.class);
                intent.putExtra("RequestedWorker", serviceNames[finalI]);
                startActivity(intent);
            });
        }
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();

        Intent intent = null;
        if (id == R.id.nav_about) {
            intent = new Intent(HomeActivity.this, AboutActivity.class);
        } else if (id == R.id.nav_logout) {
            intent = new Intent(HomeActivity.this, welcomeActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        } else if (id == R.id.nav_standardcharge) {
            intent = new Intent(HomeActivity.this, StandardCharges.class);
        }

        if (intent != null) {
            startActivity(intent);
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
